
-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `exp` varchar(255) NOT NULL,
  `dest` varchar(255) NOT NULL,
  `msg` text NOT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT '0',
  `arch` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
