
-- --------------------------------------------------------

--
-- Structure de la table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE IF NOT EXISTS `accounts` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ident` varchar(255) NOT NULL,
  `mdp` varchar(255) NOT NULL,
  `conn` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `accounts`
--

INSERT INTO `accounts` (`ID`, `ident`, `mdp`, `conn`) VALUES
(35, 'zerzer', '$argon2i$v=19$m=1024,t=2,p=2$WWFpQWNrclVoTlV0ek1iYw$qtwJ0sdVKx5VNhMULOJSLRxUaPzdYVvijwmMvr3U2n0', 0),
(34, 'aze', '$argon2i$v=19$m=1024,t=2,p=2$RUZJMFgxWGszR3ZYVmEuNQ$vSU1VxVX/Mx7fVLFvCd2Hq+vVQIWgIzF6mjr7lc1ciQ', 1);
